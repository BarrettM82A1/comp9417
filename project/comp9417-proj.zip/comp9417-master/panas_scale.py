import pandas as pd
import sklearn


def get_panas_scale(database, panas_type="post", affect='Positive'):
    # get all post type data
    if affect == 'Positive':
        panas_collection = pd.DataFrame(
            list(
                database.panas.find(
                    {
                        'type': panas_type,
                    },
                    {
                        'uid': 1,
                        'Interested': 1,
                        'Excited': 1,
                        'Strong': 1,
                        'Enthusiastic': 1,
                        'Proud': 1,
                        'Alert': 1,
                        'Inspired': 1,
                        'Determined': 1,
                        'Attentive': 1,
                        'Active': 1,
                    },
                )
            )
        )
    else:
        panas_collection = pd.DataFrame(
            list(
                database.panas.find(
                    {
                        'type': panas_type
                    },
                    {
                        'uid': 1,
                        'Distressed': 1,
                        'Upset': 1,
                        'Guilty': 1,
                        'Scared': 1,
                        'Hostile': 1,
                        'Irritable': 1,
                        'Ashamed': 1,
                        'Nervous': 1,
                        'Jittery': 1,
                        'Afraid': 1,
                    },
                )
            )
        )

    # remove '_id' column
    del panas_collection['_id']

    # drop NaN value
    panas_collection.dropna(inplace=True)

    panas_collection.sort_values(by=['uid'], ascending=[True], inplace=True)

    panas_uid = panas_collection['uid']
    del panas_collection['uid']
    panas_sum = panas_collection.sum(axis=1)

    panas = pd.DataFrame({'sum': panas_sum}).rename(index=panas_uid)

    return panas


def process_panas(panas):
    median = panas.median()[0]
    # value <= median, low, 0
    # value > median, high, 1
    binarizer = sklearn.preprocessing.Binarizer(median)
    panas.iloc[:, 0] = binarizer.transform(panas)


def get_pandas_result(pre_panas, post_panas):
    """Return pre and post panas data
    0 means low, value <= median
    1 means high, value > median

    :param pre_panas: pre panas data
    :param post_panas: post panas data
    :return: processed pre and post data
    """
    process_panas(pre_panas)
    process_panas(post_panas)

    pre_panas.rename(columns={'sum': 'pre'}, inplace=True)
    post_panas.rename(columns={'sum': 'post'}, inplace=True)
    panas = pd.concat([pre_panas, post_panas], axis=1, sort=True)
    return panas


def classify_panas(panas, affect):
    """Classify panas
    pre vote level:  low 0, high 1
    post vote level: low 2, high 4

    pre(vote) post(vote)  level
    low(0)    low(2)      2
    high(1)   low(2)      3
    low(0)    high(4)     4
    high(1)   high(4)     5

    :param panas:
    :return: classified panas
    """
    level = [0] * panas.count()['pre']
    panas[affect.lower() + '_' + 'level'] = level
    panas.loc[panas['pre'] == 1] += 1
    panas.loc[panas['post'] == 0] += 2
    panas.loc[panas['post'] == 1] = +4

    # remove data
    del panas['pre']
    del panas['post']

    # return (panas - panas.min()) / (panas.max() - panas.min())
    return panas


def get_panas_level(database, affect):
    pre_panas = get_panas_scale(database, 'pre', affect)
    post_panas = get_panas_scale(database, 'post', affect)

    panas_res = get_pandas_result(pre_panas, post_panas)

    # drop NaN value
    panas_res.dropna(inplace=True)

    return classify_panas(panas_res, affect)