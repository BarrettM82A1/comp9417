import logging

import pandas as pd

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s')
logger = logging.getLogger(__name__)


def get_percentage_from_db(database, col_prefix, participant, label_value):
    """Return list for specific data percentage from database

    :param database: database client
    :param col_prefix: collection prefix
    :param participant: participant list
    :param label_value: value in database
    :return: A list for specific data
    """
    count = []
    for parti in participant:
        logging.info("Loading %s data of %s..." % (col_prefix, parti))
        count.append(database[col_prefix + '_' + parti].count_documents(
            filter={col_prefix + ' inference': label_value}) / database[
            col_prefix + '_' + parti].count_documents({}))

    return pd.DataFrame(count, index=participant, columns=[col_prefix])
