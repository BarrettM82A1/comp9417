#!/usr/bin/env python

import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn import svm

import db
import db_duration
import db_percentage


# database client
database = db.database

output_data = db.get_output_data()
output_data.hist()
plt.show()


duration_data_names = ["conversation", "dark", "phonecharge", "phonelock", ]
duration_data = {}
for ddn in duration_data_names:
    duration_data[ddn] = db_duration.get_duration_from_db(database, ddn, output_data.index.values)

input_duration = pd.concat(
    [
        duration_data["conversation"],
        duration_data["dark"],
        duration_data["phonecharge"],
        duration_data["phonelock"]
    ],
    axis=1,
    sort=True
)
input_duration.hist()
plt.show()

activity = db_percentage.get_percentage_from_db(database, 'activity', output_data.index.values, 0)
audio = db_percentage.get_percentage_from_db(database, 'audio', output_data.index.values, 0)

input_data = pd.concat([activity, audio], axis=1, sort=True)

# print the relationship of activity/audio and flourishing scale with scatter
_t1 = pd.concat([activity, audio, output_data], axis=1, sort=True)
ax = _t1.loc[_t1['flo_level'] == 1].plot(kind='scatter', x='activity', y='audio', color='blue', label='D')
ax = _t1.loc[_t1['flo_level'] == 2].plot(kind='scatter', x='activity', y='audio', color='yellow', label='C', ax=ax)
ax = _t1.loc[_t1['flo_level'] == 4].plot(kind='scatter', x='activity', y='audio', color='green', label='B', ax=ax)
# no 5 score in output, remove this here
#ax = _t1.loc[_t1['flo_level'] == 5].plot(kind='scatter', x='activity', y='audio', color='red', label='A', ax=ax)
plt.show()

names = ["Nearest Neighbors", "Linear SVM",
         "Random Forest Classifier", ]
classfiers = [
    KNeighborsClassifier(n_neighbors=5),
    svm.SVC(kernel='linear', C=0.025),
    RandomForestClassifier(n_estimators=10),
]

# test all classifiers
for n in range(5, 11):
    # test kf from 5 to 10
    kf = KFold(n_splits=n, shuffle=True)
    print("%s Fold test:" % n)
    for name, clf in zip(names, classfiers):
        scores = cross_val_score(clf, input_data.values, output_data.values.T[0], cv=kf)
        print("%s Accuracy: %0.2f (SD +/- %0.2f)" % (name, scores.mean(), scores.std() * 2))
    print("\n")
