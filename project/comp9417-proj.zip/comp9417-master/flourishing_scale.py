import pandas as pd
import sklearn


def get_flourishing_scale(database, flo_type="post"):
    # get all post type data
    flourishing_scale_collection = pd.DataFrame(list(database.FlourishingScale.find({'type': flo_type})))

    # drop NaN value
    flourishing_scale_collection.dropna(inplace=True)
    # remove '_id' column
    del flourishing_scale_collection['_id']
    # remove 'type' column
    del flourishing_scale_collection['type']

    flourishing_scale_collection.sort_values(by=['uid'], ascending=[True], inplace=True)

    flo_uid = flourishing_scale_collection['uid']
    del flourishing_scale_collection['uid']
    flo_sum = flourishing_scale_collection.sum(axis=1)

    flo = pd.DataFrame({'sum': flo_sum}).rename(index=flo_uid)

    return flo


def process_flourishing_scale(flo):
    median = flo.median()[0]
    # value <= median, low, 0
    # value > median, high, 1
    binarizer = sklearn.preprocessing.Binarizer(median)
    flo.iloc[:, 0] = binarizer.transform(flo)


def get_flourishing_result(pre_flo, post_flo):
    """Return pre and post flourishing data
    0 means low, value <= median
    1 means high, value > median

    :param pre_flo: pre flourishing data
    :param post_flo: post flourishing data
    :return: processed pre and post data
    """
    process_flourishing_scale(pre_flo)
    process_flourishing_scale(post_flo)

    pre_flo.rename(columns={'sum': 'pre'}, inplace=True)
    post_flo.rename(columns={'sum': 'post'}, inplace=True)
    flo = pd.concat([pre_flo, post_flo], axis=1, sort=True)
    return flo


def classify_flourishing_scale(flo):
    """Classify flourishing scale
    pre vote level:  low 0, high 1
    post vote level: low 2, high 4

    pre(vote) post(vote)  level
    low(0)    low(2)      2
    high(1)   low(2)      3
    low(0)    high(4)     4
    high(1)   high(4)     5

    :param flo:
    :return: classified flourishing scale
    """
    level = [0] * flo.count()['pre']
    flo['flo_level'] = level
    flo.loc[flo['pre'] == 1] += 1
    flo.loc[flo['post'] == 0] += 2
    flo.loc[flo['post'] == 1] = +4

    # remove data
    del flo['pre']
    del flo['post']

    #return (flo - flo.min()) / (flo.max() - flo.min())
    return flo

def get_flourishing_level(database):
    pre_flo = get_flourishing_scale(database=database, flo_type='pre')
    post_flo = get_flourishing_scale(database=database, flo_type='post')

    res = get_flourishing_result(pre_flo, post_flo)

    # drop NaN value
    res.dropna(inplace=True)
    return classify_flourishing_scale(res)
