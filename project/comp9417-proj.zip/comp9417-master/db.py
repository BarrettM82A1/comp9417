"""Function for connection database"""

import pymongo
import pandas as pd

import flourishing_scale
import panas_scale
import db_percentage
import db_duration

database = pymongo.MongoClient('mongodb://localhost:27017/').StudentLife_Dataset


def get_output_data():
    # flourishing scale
    flourishing_level = flourishing_scale.get_flourishing_level(database)

    # panas
    panas_positive_level = panas_scale.get_panas_level(database, 'Positive')
    panas_negative_level = panas_scale.get_panas_level(database, 'Negative')

    # histogram for panas and flourishing level
    output_data = pd.concat([panas_negative_level, panas_positive_level, flourishing_level], axis=1, sort=True)
    output_data.dropna(inplace=True)

    return output_data


def get_input_data(output_data):
    duration_data_names = [
        "conversation",
        "dark",
        "phonecharge",
        "phonelock",
    ]
    duration_data = {}
    for ddn in duration_data_names:
        duration_data[ddn] = db_duration.get_duration_from_db(database, ddn, output_data.index.values)

    count_data_names = [
        "activity",
        "audio",
    ]
    count_data = {}
    for cdn in count_data_names:
        count_data[cdn] = db_percentage.get_percentage_from_db(
            database,
            cdn,
            output_data.index.values,
            0,
        )

    input_data = pd.concat(
        [
            duration_data["conversation"],
            duration_data["dark"],
            duration_data["phonecharge"],
            duration_data["phonelock"],
            count_data["activity"],
            count_data["audio"],
        ],
        axis=1,
        sort=True
    )

    return input_data
