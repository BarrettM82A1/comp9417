from setuptools import setup

setup(
    name='comp9417',
    version='0.1.0',
    packages=[''],
    url='',
    license='',
    author='',
    author_email='',
    description='Machine Learning and Data Mining'
)
