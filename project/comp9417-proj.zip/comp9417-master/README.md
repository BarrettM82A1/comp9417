COMP 9417
=========

Machine Learning and Data Mining

Requirements：
* MongoDB 3 (Tested on 3.6.15)
* Python 3 (Tested on 3.7)

Algorithms
----------

* Random Forest
* Linear Regression
* Neural Network

Installation
------------

1. MongoDB running on Docker

    ```
    docker run --name mongo -p 27017:27017 -v /data/mongo:/data/db -d mongo:3.6.15
    ```

2. Create database and import data

    database source download: https://www.dropbox.com/s/nrm5s3m9f46uves/StudentLife_Dataset.zip?dl=0

    ```bash
    cp -r StudentLife_Dataset/Inputs/sensing /data/mongo/
    cp StudentLife_Dataset/Outputs/FlourishingScale.csv /data/mongo/
    cp StudentLife_Dataset/Outputs/panas.csv /data/mongo/
    docker exec -it mongo bash
    cd /data/mongo/
    find . -name *.csv | xargs -t -i mongoimport --db=StudentLife_Dataset --ignoreBlanks --type=csv --file={} --headerline
    rm -rf /data/mongo/sensing
    mongoimport --db=StudentLife_Dataset --ignoreBlanks --type=csv --file=panas.csv --headerline
    mongoimport --db=StudentLife_Dataset --ignoreBlanks --type=csv --file=FlourishingScale.csv --headerline
    rm -rf /data/mongo/FlourishingScale.csv /data/mongo/panas.csv
    ```

3. Install requirements

   ```bash
   pip install -r requirements.txt
   ```

Database Structure
------------------

* DB Description: https://studentlife.cs.dartmouth.edu/dataset.html
* DB Name: StudentLife_Dataset

```bash
docker exec -it mongo bash
root@5af713fc7cb4:/# mongo
MongoDB shell version v3.6.15
connecting to: mongodb://127.0.0.1:27017/?gssapiServiceName=mongodb
Implicit session: session { "id" : UUID("af184c66-6b8c-4234-b442-84da3e9feb6e") }
MongoDB server version: 3.6.15
Welcome to the MongoDB shell.
For interactive help, type "help".
For more comprehensive documentation, see
	http://docs.mongodb.org/
Questions? Try the support group
	http://groups.google.com/group/mongodb-user
Server has startup warnings:
2019-11-13T07:04:42.642+0000 I CONTROL  [initandlisten]
2019-11-13T07:04:42.642+0000 I CONTROL  [initandlisten] ** WARNING: Access control is not enabled for the database.
2019-11-13T07:04:42.642+0000 I CONTROL  [initandlisten] **          Read and write access to data and configuration is unrestricted.
2019-11-13T07:04:42.642+0000 I CONTROL  [initandlisten]
> show dbs
StudentLife_Dataset  3.979GB
admin                0.000GB
config               0.000GB
local                0.000GB
> use StudentLife_Dataset
switched to db StudentLife_Dataset
> show collections
FlourishingScale
activity_u00
activity_u01
activity_u02
activity_u03
activity_u04
activity_u05
activity_u07
activity_u08
activity_u09
activity_u10
activity_u12
activity_u13
activity_u14
activity_u15
activity_u16
activity_u17
activity_u18
activity_u19
activity_u20
activity_u22
activity_u23
activity_u24
activity_u25
activity_u27
activity_u30
activity_u31
activity_u32
activity_u33
activity_u34
activity_u35
activity_u36
activity_u39
activity_u41
activity_u42
activity_u43
activity_u44
activity_u45
activity_u46
activity_u47
activity_u49
activity_u50
activity_u51
activity_u52
activity_u53
activity_u54
activity_u56
activity_u57
activity_u58
activity_u59
audio_u00
audio_u01
audio_u02
audio_u03
audio_u04
audio_u05
audio_u07
audio_u08
audio_u09
audio_u10
audio_u12
audio_u13
audio_u14
audio_u15
audio_u16
audio_u17
audio_u18
audio_u19
audio_u20
audio_u22
audio_u23
audio_u24
audio_u25
audio_u27
audio_u30
audio_u31
audio_u32
audio_u33
audio_u34
audio_u35
audio_u36
audio_u39
audio_u41
audio_u42
audio_u43
audio_u44
audio_u45
audio_u46
audio_u47
audio_u49
audio_u50
audio_u51
audio_u52
audio_u53
audio_u54
audio_u56
audio_u57
audio_u58
audio_u59
bt_u00
bt_u01
bt_u02
bt_u03
bt_u04
bt_u05
bt_u07
bt_u08
bt_u09
bt_u10
bt_u12
bt_u13
bt_u14
bt_u15
bt_u16
bt_u17
bt_u18
bt_u19
bt_u20
bt_u22
bt_u23
bt_u24
bt_u25
bt_u27
bt_u30
bt_u31
bt_u32
bt_u33
bt_u34
bt_u35
bt_u36
bt_u39
bt_u41
bt_u42
bt_u43
bt_u44
bt_u45
bt_u46
bt_u47
bt_u49
bt_u50
bt_u51
bt_u52
bt_u53
bt_u54
bt_u56
bt_u57
bt_u58
bt_u59
conversation_u00
conversation_u01
conversation_u02
conversation_u03
conversation_u04
conversation_u05
conversation_u07
conversation_u08
conversation_u09
conversation_u10
conversation_u12
conversation_u13
conversation_u14
conversation_u15
conversation_u16
conversation_u17
conversation_u18
conversation_u19
conversation_u20
conversation_u22
conversation_u23
conversation_u24
conversation_u25
conversation_u27
conversation_u30
conversation_u31
conversation_u32
conversation_u33
conversation_u34
conversation_u35
conversation_u36
conversation_u39
conversation_u41
conversation_u42
conversation_u43
conversation_u44
conversation_u45
conversation_u46
conversation_u47
conversation_u49
conversation_u50
conversation_u51
conversation_u52
conversation_u53
conversation_u54
conversation_u56
conversation_u57
conversation_u58
conversation_u59
dark_u00
dark_u01
dark_u02
dark_u03
dark_u04
dark_u05
dark_u07
dark_u08
dark_u09
dark_u10
dark_u12
dark_u13
dark_u14
dark_u15
dark_u16
dark_u17
dark_u18
dark_u19
dark_u20
dark_u22
dark_u23
dark_u24
dark_u25
dark_u27
dark_u30
dark_u31
dark_u32
dark_u33
dark_u34
dark_u35
dark_u36
dark_u39
dark_u41
dark_u42
dark_u43
dark_u44
dark_u45
dark_u46
dark_u47
dark_u49
dark_u50
dark_u51
dark_u52
dark_u53
dark_u54
dark_u56
dark_u57
dark_u58
dark_u59
gps_u00
gps_u01
gps_u02
gps_u03
gps_u04
gps_u05
gps_u07
gps_u08
gps_u09
gps_u10
gps_u12
gps_u13
gps_u14
gps_u15
gps_u16
gps_u17
gps_u18
gps_u19
gps_u20
gps_u22
gps_u23
gps_u24
gps_u25
gps_u27
gps_u30
gps_u31
gps_u32
gps_u33
gps_u34
gps_u35
gps_u36
gps_u39
gps_u41
gps_u42
gps_u43
gps_u44
gps_u45
gps_u46
gps_u47
gps_u49
gps_u50
gps_u51
gps_u52
gps_u53
gps_u54
gps_u56
gps_u57
gps_u58
gps_u59
panas
phonecharge_u00
phonecharge_u01
phonecharge_u02
phonecharge_u03
phonecharge_u04
phonecharge_u05
phonecharge_u07
phonecharge_u08
phonecharge_u09
phonecharge_u10
phonecharge_u12
phonecharge_u13
phonecharge_u14
phonecharge_u15
phonecharge_u16
phonecharge_u17
phonecharge_u18
phonecharge_u19
phonecharge_u20
phonecharge_u22
phonecharge_u23
phonecharge_u24
phonecharge_u25
phonecharge_u27
phonecharge_u30
phonecharge_u31
phonecharge_u32
phonecharge_u33
phonecharge_u34
phonecharge_u35
phonecharge_u36
phonecharge_u39
phonecharge_u41
phonecharge_u42
phonecharge_u43
phonecharge_u44
phonecharge_u45
phonecharge_u46
phonecharge_u47
phonecharge_u49
phonecharge_u50
phonecharge_u51
phonecharge_u52
phonecharge_u53
phonecharge_u54
phonecharge_u56
phonecharge_u57
phonecharge_u58
phonecharge_u59
phonelock_u00
phonelock_u01
phonelock_u02
phonelock_u03
phonelock_u04
phonelock_u05
phonelock_u07
phonelock_u08
phonelock_u09
phonelock_u10
phonelock_u12
phonelock_u13
phonelock_u14
phonelock_u15
phonelock_u16
phonelock_u17
phonelock_u18
phonelock_u19
phonelock_u20
phonelock_u22
phonelock_u23
phonelock_u24
phonelock_u25
phonelock_u27
phonelock_u30
phonelock_u31
phonelock_u32
phonelock_u33
phonelock_u34
phonelock_u35
phonelock_u36
phonelock_u39
phonelock_u41
phonelock_u42
phonelock_u43
phonelock_u44
phonelock_u45
phonelock_u46
phonelock_u47
phonelock_u49
phonelock_u50
phonelock_u51
phonelock_u52
phonelock_u53
phonelock_u54
phonelock_u56
phonelock_u57
phonelock_u58
phonelock_u59
wifi_location_u00
wifi_location_u01
wifi_location_u02
wifi_location_u03
wifi_location_u04
wifi_location_u05
wifi_location_u07
wifi_location_u08
wifi_location_u09
wifi_location_u10
wifi_location_u12
wifi_location_u13
wifi_location_u14
wifi_location_u15
wifi_location_u16
wifi_location_u17
wifi_location_u18
wifi_location_u19
wifi_location_u20
wifi_location_u22
wifi_location_u23
wifi_location_u24
wifi_location_u25
wifi_location_u27
wifi_location_u30
wifi_location_u31
wifi_location_u32
wifi_location_u33
wifi_location_u34
wifi_location_u35
wifi_location_u36
wifi_location_u39
wifi_location_u41
wifi_location_u42
wifi_location_u43
wifi_location_u44
wifi_location_u45
wifi_location_u46
wifi_location_u47
wifi_location_u49
wifi_location_u50
wifi_location_u51
wifi_location_u52
wifi_location_u53
wifi_location_u54
wifi_location_u56
wifi_location_u57
wifi_location_u58
wifi_location_u59
wifi_u00
wifi_u01
wifi_u02
wifi_u03
wifi_u04
wifi_u05
wifi_u07
wifi_u08
wifi_u09
wifi_u10
wifi_u12
wifi_u13
wifi_u14
wifi_u15
wifi_u16
wifi_u17
wifi_u18
wifi_u19
wifi_u20
wifi_u22
wifi_u23
wifi_u24
wifi_u25
wifi_u27
wifi_u30
wifi_u31
wifi_u32
wifi_u33
wifi_u34
wifi_u35
wifi_u36
wifi_u39
wifi_u41
wifi_u42
wifi_u43
wifi_u44
wifi_u45
wifi_u46
wifi_u47
wifi_u49
wifi_u50
wifi_u51
wifi_u52
wifi_u53
wifi_u54
wifi_u56
wifi_u57
wifi_u58
wifi_u59
```
