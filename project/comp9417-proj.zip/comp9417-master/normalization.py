def min_max_normalization(x):
    return (x-x.min())/(x.max()-x.min())


def z_score_normalization(x):
    return (x-x.mean())/x.std()
