#!/usr/bin/env python

import logging

import pandas as pd
import matplotlib.pyplot as plt

from sklearn.preprocessing import Binarizer
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn import svm

import db

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s')
logger = logging.getLogger(__name__)


output_data = db.get_output_data()
input_data = db.get_input_data(output_data)


names = ["Nearest Neighbors", "Linear SVM",
         "Random Forest Classifier", ]
classfiers = [
    KNeighborsClassifier(n_neighbors=5),
    svm.SVC(kernel='linear', C=0.025),
    RandomForestClassifier(n_estimators=10),
]

# test all classifiers
for n in range(5, 11):
    # test kf from 5 to 10
    kf = KFold(n_splits=n, shuffle=True)
    logging.info("%s Fold test:" % n)
    for name, clf in zip(names, classfiers):
        scores = cross_val_score(clf, input_data.values, output_data.values.T[0], cv=kf)
        logging.info("%s Accuracy: %0.2f (SD +/- %0.2f)" % (name, scores.mean(), scores.std() * 2))
