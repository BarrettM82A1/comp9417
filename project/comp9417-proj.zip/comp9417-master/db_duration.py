import logging

import pandas as pd

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s')
logger = logging.getLogger(__name__)


def get_duration_from_db(database, col_prefix, participant):
    duration = []
    for parti in participant:
        logging.info("Loading %s data of %s..." % (col_prefix, parti))
        _data = pd.DataFrame(list(database[col_prefix + '_' + parti].find({})))

        # conversation column names are 'start_timestamp' and 'end_timestamp'
        # while others are 'start' and end
        try:
            duration.append((_data['end'] - _data['start']).sum())
        except KeyError:
            duration.append((_data['end_timestamp'] - _data['start_timestamp']).sum())

    return pd.DataFrame(duration, index=participant, columns=[col_prefix])
